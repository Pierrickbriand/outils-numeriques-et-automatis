# Le kit de votre projet Claude

Quatre dossiers, à utiliser dans cet ordre (séance 1, étapes 4 à 9 du cours) :

1. **1-INSTRUCTIONS-DU-PROJET.txt** : à copier dans les instructions de votre projet Claude, après avoir complété les {accolades}.
2. **2-fichiers-du-projet** : les huit fichiers à ajouter au projet. Claude les lit dans chaque conversation. Ajoutez aussi les documents 01, 02 et 03 du kit d’Ondée.
3. **3-consignes** : la consigne de chacune des 13 conversations. Une conversation par consigne, renommée avec son titre.
4. **4-code-de-depart** : le code de l’application à coller dans Apps Script en conversation 02. Claude l’adapte à votre charte.

À la fin de chaque conversation, Claude vous donne ETAT-DU-PROJET.md mis à jour : remplacez l’ancien fichier dans le projet. C’est la mémoire de votre projet d’une conversation à l’autre.

Économisez vos crédits : une conversation courte par étape ; Gemini, en offre gratuite, pour les textes, les idées et les explications de formules.
