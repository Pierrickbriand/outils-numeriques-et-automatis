/**
 * {NOM DE L'APPLICATION} · code serveur (Google Apps Script)
 *
 * Code de départ fourni par le cours « Outils numériques et automatisés ».
 * Il affiche l'application, lit le fichier data et enregistre un nouveau contact.
 * Claude le complète ensuite, conversation après conversation : une fonctionnalité à la fois.
 *
 * Le projet Apps Script est ouvert depuis le fichier data (Extensions, Apps Script) : il le lit directement.
 * Si vous l'avez créé ailleurs, collez l'identifiant du fichier data ci-dessous : la longue suite de caractères
 * de son adresse, entre /d/ et /edit.
 */
const ID_FICHIER_DATA = '';

const NOM_APPLICATION = "{NOM DE L'APPLICATION}";

// Les onglets du fichier data, tels qu'ils sont nommés dans le fichier : ne pas les renommer.
const ONGLETS = {
  parametres: 'Paramètres',
  entreprises: 'Entreprises',
  contacts: 'Contacts',
  affaires: 'Affaires',
  interactions: 'Interactions',
  rendezVous: 'Rendez-vous',
  catalogue: 'Catalogue',
  veille: 'Veille',
  modeles: 'Modèles e-mails',
  envois: 'Envois programmés',
  journal: 'Journal'
};

// Les huit étapes du cycle de vente, dans l'ordre.
const ETAPES = ['Veille', 'Prospection', 'Qualification', 'Rendez-vous', 'Proposition', 'Négociation', 'Suivi', 'Fidélisation'];

/** Affiche l'application web. */
function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(NOM_APPLICATION)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/** Insère un autre fichier HTML du projet (Styles, Script) dans la page. */
function inclure(nom) {
  return HtmlService.createHtmlOutputFromFile(nom).getContent();
}

/** Ouvre le fichier data. */
function classeur_() {
  return ID_FICHIER_DATA ? SpreadsheetApp.openById(ID_FICHIER_DATA) : SpreadsheetApp.getActiveSpreadsheet();
}

/** Lit un onglet et le renvoie sous forme de liste d'objets : une ligne = un objet, une colonne = une propriété. */
function lireOnglet_(nom) {
  const feuille = classeur_().getSheetByName(nom);
  if (!feuille) throw new Error("Onglet introuvable dans le fichier data : " + nom);
  const valeurs = feuille.getDataRange().getValues();
  const entetes = valeurs.shift();
  const fuseau = Session.getScriptTimeZone();
  return valeurs
    .filter(function (ligne) { return ligne[0] !== ''; })
    .map(function (ligne) {
      const objet = {};
      entetes.forEach(function (entete, i) {
        const v = ligne[i];
        // Les dates partent vers la page sous forme de texte : la page ne sait pas recevoir un objet Date.
        objet[entete] = (v instanceof Date) ? Utilities.formatDate(v, fuseau, 'yyyy-MM-dd') : v;
      });
      return objet;
    });
}

/** Ajoute une ligne au journal de l'application. */
function journaliser_(action, detail) {
  const feuille = classeur_().getSheetByName(ONGLETS.journal);
  if (feuille) feuille.appendRow([new Date(), action, detail || '']);
}

/** Vérifie que l'application lit bien le fichier data. À lancer une fois depuis l'éditeur. */
function testerConnexion() {
  const affaires = lireOnglet_(ONGLETS.affaires);
  const contacts = lireOnglet_(ONGLETS.contacts);
  Logger.log('Connexion réussie : %s affaires et %s contacts lus.', affaires.length, contacts.length);
  return affaires.length + ' affaires et ' + contacts.length + ' contacts lus.';
}

/** Données de la page d'accueil : chiffres clés et affaires par étape. */
function donneesAccueil() {
  const affaires = lireOnglet_(ONGLETS.affaires);
  const enCours = affaires.filter(function (a) { return a['Statut'] === 'En cours'; });
  const somme = function (liste, col) { return liste.reduce(function (t, a) { return t + (Number(a[col]) || 0); }, 0); };
  const parEtape = ETAPES.map(function (e) {
    const liste = affaires.filter(function (a) { return a['Étape'] === e && a['Statut'] !== 'Perdue'; });
    return { etape: e, nombre: liste.length, montant: somme(liste, 'Montant HT') };
  });
  const aRelancer = enCours
    .filter(function (a) { return a['À relancer'] === 'Oui'; })
    .map(function (a) { return { id: a['ID'], intitule: a['Intitulé'], entreprise: a['Entreprise'], jours: a['Jours sans contact'], etape: a['Étape'] }; })
    .sort(function (x, y) { return y.jours - x.jours; });
  return {
    application: NOM_APPLICATION,
    chiffres: {
      enCours: enCours.length,
      pipelinePondere: Math.round(somme(enCours, 'Montant pondéré')),
      caSigne: somme(affaires.filter(function (a) { return a['Statut'] === 'Gagnée'; }), 'Montant HT'),
      aRelancer: aRelancer.length
    },
    parEtape: parEtape,
    aRelancer: aRelancer
  };
}

/** Liste des contacts, avec leur entreprise, pour l'écran « Contacts ». */
function listeContacts() {
  return lireOnglet_(ONGLETS.contacts).map(function (c) {
    return { id: c['ID'], nom: c['Nom complet'], fonction: c['Fonction'], role: c['Rôle'], entreprise: c['Entreprise'], email: c['E-mail'] };
  });
}

/** Liste des entreprises, pour la liste déroulante du formulaire. */
function listeEntreprises() {
  return lireOnglet_(ONGLETS.entreprises).map(function (e) { return { id: e['ID'], nom: e['Raison sociale'] }; });
}

/** Enregistre un nouveau contact saisi dans l'application. Renvoie son identifiant. */
function ajouterContact(contact) {
  if (!contact || !contact.prenom || !contact.nom || !contact.entrepriseId) {
    throw new Error('Prénom, nom et entreprise sont obligatoires.');
  }
  const feuille = classeur_().getSheetByName(ONGLETS.contacts);
  const derniere = feuille.getLastRow();
  const ids = feuille.getRange(2, 1, Math.max(derniere - 1, 1), 1).getValues().map(function (l) { return String(l[0]); });
  const max = ids.reduce(function (m, id) { const n = parseInt(id.replace('C', ''), 10); return isNaN(n) ? m : Math.max(m, n); }, 0);
  const id = 'C' + String(max + 1).padStart(2, '0');
  const r = derniere + 1;
  // Les colonnes calculées reprennent les formules du fichier data.
  feuille.getRange(r, 1, 1, 12).setValues([[
    id, contact.prenom.trim(), contact.nom.trim(), contact.fonction || '', contact.role || 'Acheteur', contact.entrepriseId,
    '=IFERROR(INDEX(Entreprises!B:B,MATCH(F' + r + ',Entreprises!A:A,0)),"")',
    `=IF('Paramètres'!$B$3="","à compléter : Paramètres, B3",SUBSTITUTE(LOWER(TRIM('Paramètres'!$B$3)),"@","+"&LOWER(A${r})&"@"))`,
    contact.telephone || '', 'Non', '',
    '=B' + r + '&" "&UPPER(C' + r + ')'
  ]]);
  journaliser_('Nouveau contact', id + ' · ' + contact.prenom + ' ' + contact.nom);
  return id;
}
