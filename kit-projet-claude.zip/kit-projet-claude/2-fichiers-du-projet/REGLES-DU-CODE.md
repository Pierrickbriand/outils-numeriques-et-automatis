# Règles du code

Pour Claude, à respecter dans chaque conversation.

## Le projet Apps Script
– Quatre fichiers : Code.gs (serveur), Index.html (structure), Styles.html (charte), Script.html (code de la page). Le code de départ du cours en est la base : garder ses fonctions classeur_, lireOnglet_ et journaliser_.
– Projet ouvert depuis le fichier data (Extensions, Apps Script) : SpreadsheetApp.getActiveSpreadsheet() le lit.
– Moteur V8, fuseau horaire Europe/Paris.
– Noms des fonctions et des variables en français, sans accent ; un commentaire d'une ligne en tête de chaque fonction.
– Aucune bibliothèque externe, sauf Google Fonts.

## Les données
– Lire un onglet avec lireOnglet_(nom) : les colonnes se lisent par leur nom (MODELE-DE-DONNEES.md). Ne jamais renommer un onglet ni une colonne.
– Les colonnes calculées contiennent des formules : ne pas les écraser. Pour une nouvelle ligne, recopier la formule de la ligne au-dessus.
– Les dates partent vers la page en texte (aaaa-mm-jj) : la page ne reçoit pas d'objet Date.
– Les seuils et les règles se lisent dans l'onglet Paramètres, jamais en dur dans le code.

## La page
– Appels au serveur avec google.script.run, toujours avec withSuccessHandler et withFailureHandler ; une erreur s'affiche en clair.
– Interface en français, accessible au clavier, lisible sur téléphone.

## Gmail, Agenda, Drive, Docs, Slides
– N'écrire qu'aux adresses du fichier data, jamais à un contact dont la colonne Opposition vaut « Oui ».
– Quota Google des comptes gratuits : 100 destinataires par jour.
– Les déclencheurs sont créés par une seule fonction, installerDeclencheurs, qui supprime d'abord les anciens.
– Les documents créés sont rangés dans le dossier Drive de l'application.

## Livrer
– Chaque fichier modifié en entier, avec son nom ; jamais un morceau à insérer.
– Pendant la construction : « Déployer », « Tester les déploiements » (lien de test toujours à jour). La publication réelle se fait en conversation 13.
– Une erreur : demander le message exact et le journal d'exécution (« Exécutions » dans Apps Script).
