# Charte éditoriale : {NOM DE L’APPLICATION}

À compléter en conversation 01. Elle vaut pour les textes de l’interface et pour les e-mails envoyés par l’application.

– Ton : {ex. direct, chaleureux, précis}
– Adresse aux clients : vouvoiement
– Longueur : phrases courtes, un e-mail de 120 mots au plus
– Signature des e-mails : {Prénom NOM}, ingénieur d’affaires, Ondée
– Mots à employer : {…}
– Mots à éviter : {…}

Règles :
– chaque e-mail de prospection permet de s’opposer (« Répondez “stop” si vous ne souhaitez plus recevoir mes messages. ») ;
– aucun chiffre ni engagement inventé : seulement ceux du fichier data et du catalogue ;
– typographie française : guillemets « », espace insécable avant : ; ! ?, montants en euros (1 250 €).
