# Cahier de commande : {NOM DE L’APPLICATION}

Il fixe l’utilisateur, les tâches à automatiser et les données d’entrée et de sortie, avant toute formule ou ligne de code. À compléter en conversation 01.

## L’utilisateur
– Qui utilise l’application : {…}
– Ce qu’il fait chaque jour, chaque semaine : {…}
– Ce qui lui fait perdre du temps ou des affaires : {…}

## Les tâches à automatiser dans le cycle de vente
Une ligne par tâche : l’étape, la tâche, ce que fait l’application, ce que l’utilisateur garde.
– Veille : {…}
– Prospection : {…}
– Qualification : {…}
– Rendez-vous : {…}
– Proposition : {…}
– Négociation : {…}
– Suivi : {…}
– Fidélisation : {…}

## Les données d’entrée
Ce que l’application lit : les onglets du fichier data, les e-mails reçus, l’agenda, les modèles.
{…}

## Les données de sortie
Ce que l’application produit : e-mails, événements, devis, plaquettes, rapports, alertes, lignes du fichier data.
{…}

## Ce que l’application ne fait pas
La relation et la décision restent humaines : {…}
