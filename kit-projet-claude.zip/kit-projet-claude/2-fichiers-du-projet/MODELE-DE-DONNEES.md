# Modèle de données : le fichier data « Ondée · données commerciales »

Pour Claude : les onglets et les colonnes ci-dessous sont les seuls qui existent. Les lire par leur nom ; ne jamais en inventer, ni les renommer. Colonnes (formule) : calculées, à ne pas écraser. Les noms de colonnes s'écrivent avec l'apostrophe droite ('), exactement comme ci-dessous.

## Paramètres

Réglages lus par l'application (B3 à B15) et table des huit étapes (lignes 18 à 25).

## Catalogue

L'offre professionnelle : prix selon la quantité, coût de revient, délai.

Colonnes : Réf. ; Produit ; Description ; Prix public TTC ; Prix pro HT ; Prix pro HT dès 50 ; Prix pro HT dès 200 ; Coût de revient ; Délai de fabrication (jours) ; Minimum de commande ; Marge pro (formule).

## Entreprises

Une ligne par entreprise.

Colonnes : ID ; Raison sociale ; Secteur ; Ville ; Département ; Effectif ; Site web ; Taille (formule) ; Nombre d'affaires (formule) ; CA signé (€ HT) (formule).

## Contacts

Une ligne par personne ; l'e-mail est un alias de la boîte de l'étudiant.

Colonnes : ID ; Prénom ; Nom ; Fonction ; Rôle ; Entreprise ID ; Entreprise (formule) ; E-mail (formule) ; Téléphone ; Opposition ; Dernier contact (formule) ; Nom complet (formule).

## Affaires

Une ligne par affaire : étape, statut, montant, relance, livraison, qualification.

Colonnes : ID ; Intitulé ; Entreprise ID ; Entreprise (formule) ; Contact ID ; Contact (formule) ; Statut ; Étape ; Produit (réf.) ; Quantité ; Montant HT (formule) ; Remise ; Probabilité (formule) ; Montant pondéré (formule) ; Date d'ouverture (formule) ; Dernière action (formule) ; Jours sans contact (formule) ; À relancer (formule) ; Prochaine action ; Date de la prochaine action (formule) ; Décideur requis (formule) ; Remise hors délégation (formule) ; Coût de revient (formule) ; Marge (formule) ; Livraison prévue (formule) ; Livraison réelle (formule) ; Retard (jours) (formule) ; Coût prévu (formule) ; Coût réel ; Écart de coût (formule) ; Satisfaction (sur 5) ; Besoin ; Budget ; Décideur ; Calendrier ; Score de qualification (formule) ; Date de qualification (formule) ; Lien du devis ; Lien de la plaquette.

## Interactions

Un échange par ligne : e-mail, appel, rendez-vous.

Colonnes : Date (formule) ; Contact ID ; Affaire ID ; Canal ; Sens ; Objet ; Résumé ; Contact (formule).

## Rendez-vous

Rendez-vous prévus ou passés, reliés à l'agenda.

Colonnes : Date (formule) ; Heure ; Durée (min) ; Affaire ID ; Contact ID ; Contact (formule) ; Entreprise (formule) ; Lieu ; Objet ; Dans l'agenda ; Statut (formule) ; ID de l'événement.

## Veille

Signaux d'affaires datés.

Colonnes : Date (formule) ; Entreprise ID ; Entreprise (formule) ; Type ; Signal ; Source ; Exploité ; Affaire liée (formule).

## Modèles e-mails

Modèles avec balises {Prénom}, {Entreprise}, {Signal}, {Commercial}, {Date}.

Colonnes : Code ; Étape ; Objet ; Corps.

## Envois programmés

File d'attente des e-mails programmés, vidée par un déclencheur.

Colonnes : Date et heure d'envoi ; Contact ID ; Destinataire ; Objet ; Corps ; Statut ; Envoyé le.

## Journal

Une ligne par action de l'application.

Colonnes : Date et heure ; Action ; Détail.

## Indicateurs

Chiffres clés calculés par formules (lecture seule pour l'application).

## Export brut

Exercices de nettoyage : l'application ne le lit pas.

Colonnes : Client ; Ville ; E-mail ; Date de commande ; Montant ; Produit.

## Valeurs fixes

– Étapes : Veille, Prospection, Qualification, Rendez-vous, Proposition, Négociation, Suivi, Fidélisation.
– Statuts : En cours, Gagnée, Perdue.
– Rôles : Utilisateur, Prescripteur, Acheteur, Décideur.
– Canaux : E-mail, Téléphone, Rendez-vous, LinkedIn, Courrier ; sens : Entrant, Sortant.
