# Feuille de route : les 13 conversations du projet

Une conversation par étape, dans le projet Claude. Chacune commence par la consigne du cours et se termine par la mise à jour d’ETAT-DU-PROJET.md. Renommez chaque conversation avec son titre.

| N° | Titre | Séance | Fonctionnalités | Services Google |
|---|---|---|---|---|
| 01 | Cadrage et créativité | séance 1 | aucune | Claude seul |
| 02 | Fondations | séance 1 | aucune (installation) | Sheets, Apps Script |
| 03 | Interface et contacts | séance 2 | F1, F2 | Sheets |
| 04 | Veille | séance 2 | F3 | Sheets, Docs |
| 05 | Prospection | séance 2 | F4 | Gmail, Sheets |
| 06 | Qualification | séance 2 | F5 | Sheets |
| 07 | Rendez-vous | séance 3 | F6, F7 | Agenda, Gmail |
| 08 | Proposition | séance 3 | F8, F9 | Docs, Slides, Drive, Gmail |
| 09 | Négociation | séance 3 | F10 | Sheets |
| 10 | Suivi | séance 4 | F11, F12 | Gmail, déclencheurs |
| 11 | Fidélisation | séance 4 | F13 | Gmail, Sheets (Forms en option) |
| 12 | Rapports et tableau de bord | séance 4 | F14 | Docs, Sheets, Drive |
| 13 | Alerte hebdomadaire, publication et accès | séance 4 | F15, F16 | Gmail, déclencheurs, Apps Script, Drive |

Entre deux séances, avancez à votre rythme : une conversation à la fois, vérifiée sur les données avant de passer à la suivante.
