# Charte graphique : {NOM DE L’APPLICATION}

À compléter en conversation 01. Le code de départ lit ces couleurs dans Styles.html (variables en tête du fichier).

– Couleur principale (en-tête, menu actif) : {ex. #1F3D66}
– Couleur d’accent (boutons, barres) : {ex. #1D6F69}
– Couleur d’alerte (relances, retards) : {ex. #A8425A}
– Fond et cartes : {ex. #F3F3F6 et blanc}
– Police : {ex. Poppins (Google Fonts)}
– Logo ou symbole : {un caractère, un émoji ou une image hébergée dans votre Drive}
– Style : {sobre, chaleureux, technique}

Règles :
– contraste lisible : texte foncé sur fond clair ;
– trois couleurs au plus, en plus du fond ;
– la charte d’Ondée (document 06 du kit) peut servir de point de départ.
