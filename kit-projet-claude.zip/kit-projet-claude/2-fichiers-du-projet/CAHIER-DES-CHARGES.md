# Cahier des charges : {NOM DE L’APPLICATION}

Application web de pilotage du cycle de vente d’Ondée. Ondée est une entreprise fictive : clients, contacts et chiffres sont inventés.

## La problématique

Un ingénieur d’affaires d’Ondée perd des affaires faute de suivi : contacts dispersés, relances oubliées, rendez-vous mal préparés, propositions longues à produire. Comment piloter les huit étapes du cycle de vente depuis une seule application, branchée sur les outils Google, pour gagner du temps et ne laisser filer aucune affaire ?

## L’utilisateur

L’ingénieur d’affaires d’Ondée : il prospecte, rencontre et suit une trentaine d’affaires à la fois. Sa directrice commerciale lit ses chiffres chaque lundi.

## Les fonctionnalités imposées

| N° | Étape | Fonctionnalité | Services Google | Conversation |
|---|---|---|---|---|
| F1 | Pilotage | Accueil : affaires en cours, pipeline pondéré, chiffre d’affaires signé, affaires à relancer, rendez-vous à venir | Sheets | 02, 03 |
| F2 | Pilotage | Contacts et entreprises : liste, fiche, création et modification depuis l’interface | Sheets | 03 |
| F3 | Veille | Signaux de veille, affaire créée en un clic, résumé de veille dans un document | Sheets, Docs | 04 |
| F4 | Prospection | E-mail de prise de contact tiré d’un modèle, personnalisé, envoyé ou programmé | Gmail, Sheets | 05 |
| F5 | Qualification | Grille besoin, budget, décideur, calendrier sur 4 ; décideur requis au-delà du seuil | Sheets | 06 |
| F6 | Rendez-vous | Rendez-vous créé dans Google Agenda, contact invité | Agenda, Sheets | 07 |
| F7 | Rendez-vous | Rendez-vous à venir lus dans l’agenda ; « rendez-vous à prendre » signalé | Agenda | 07 |
| F8 | Proposition | Devis Google Docs tiré d’un modèle, PDF rangé dans un dossier Drive du client | Docs, Drive | 08 |
| F9 | Proposition | Plaquette Google Slides personnalisée | Slides, Drive | 08 |
| F10 | Négociation | Remise et délai recalculés ; alertes de délégation, de marge et de décideur | Sheets | 09 |
| F11 | Suivi | E-mails reçus des contacts lus automatiquement ; étape et action à mener affichées | Gmail, déclencheurs | 10 |
| F12 | Suivi | E-mails programmés envoyés à leur date | Gmail, déclencheurs | 10 |
| F13 | Fidélisation | Enquête de satisfaction, réassort, recommandation | Gmail (Forms en option) | 11 |
| F14 | Pilotage | Tableau de bord qualité-coût-délai et rapport d’activité en PDF | Docs, Sheets, Drive | 12 |
| F15 | Pilotage | Alerte hebdomadaire par e-mail, chaque lundi, avec un commentaire d’alerte | Gmail, déclencheurs | 13 |
| F16 | Pilotage | Application publiée, accès contrôlés, fichier data partagé en lecture et protégé | Apps Script, Drive | 13 |

## Les exigences

– Les données vivent dans le fichier data « Ondée · données commerciales » (Google Sheets), décrit dans MODELE-DE-DONNEES.md.
– Aucune donnée réelle : les contacts ont des adresses alias de la boîte Gmail de l’étudiant.
– Aucun e-mail à un contact qui s’est opposé ; chaque e-mail de prospection permet de s’opposer.
– L’interface suit CHARTE-GRAPHIQUE.md ; les textes suivent CHARTE-EDITORIALE.md.
– Chaque action importante laisse une ligne dans l’onglet Journal.

## Mes choix (à compléter en conversation 01)

– Nom de l’application : {NOM DE L’APPLICATION}
– Slogan : {SLOGAN}
– Problématique, dans mes mots (je peux l’élargir) : {…}
– Utilisateurs : {…}
– Mes trois fonctionnalités prioritaires : {…}
– Mes évolutions personnelles (F17 et plus) : {…}

## Ce qui est évalué (27 mai 2027)

L’application et son tableau de bord, notés sur 20 avec la grille du cours : fonctionnalités, fiabilité vérifiée sur les données, tableau de bord qualité-coût-délai, automatisations, publication et accès, documentation du projet, interface.
