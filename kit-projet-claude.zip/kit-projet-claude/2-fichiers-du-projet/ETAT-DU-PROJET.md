# État du projet : {NOM DE L’APPLICATION}

Mis à jour le : {date}, à la fin de la conversation {numéro}.

## Ce qui marche
– Rien encore : le projet commence.

## Les fonctionnalités
– F1 à F16 : à faire.
– Mes évolutions : à définir en conversation 01.

## Les décisions prises
– {…}

## Les problèmes connus
– Aucun.

## La prochaine conversation
01 · Cadrage et créativité.

## Les adresses (à remplir au fil du projet)
– Fichier data : {lien}
– Application (lien de test) : {lien}
– Application publiée : {lien, conversation 13}
