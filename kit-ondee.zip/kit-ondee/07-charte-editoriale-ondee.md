# La charte éditoriale d’Ondée

Document fictif, créé pour le cours.

– Ton : direct, chaleureux, précis. On parle du quotidien du client : la pluie, la tournée, la sécurité.
– Les clients sont vouvoyés ; l’équipe se tutoie.
– Phrases courtes : vingt mots au plus. Un e-mail : 120 mots au plus, une seule question finale.
– On cite un fait propre au client (un signal, un chiffre du fichier data), jamais un chiffre inventé.
– Mots d’Ondée : au sec, réparer, échanger, personnaliser, atelier de Saint-Nazaire.
– Mots à éviter : « révolutionnaire », « leader », « solution innovante », « n’hésitez pas à ».
– Chaque e-mail de prospection permet de s’opposer : « Répondez “stop” si vous ne souhaitez plus recevoir mes messages. »
– Typographie française : guillemets « », espace insécable avant : ; ! ?, montants écrits 1 250 € HT.
– Signature : Prénom NOM, ingénieur d’affaires, Ondée · Saint-Nazaire.
