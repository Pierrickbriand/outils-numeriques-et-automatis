# Les modèles d’e-mails d’Ondée

Document fictif, créé pour le cours. Les mêmes modèles sont dans l’onglet « Modèles e-mails » du fichier data. L’application remplace les balises {Prénom}, {Entreprise}, {Signal}, {Commercial} et {Date}.

## M01 · Prospection

Objet : {Entreprise} : vos équipes au sec cet hiver

Bonjour {Prénom},

J’ai vu que {Signal}. Vos équipes travaillent dehors : comment les équipez-vous contre la pluie aujourd’hui ?

Ondée fabrique à Saint-Nazaire des vestes de pluie personnalisées pour les professionnels. Un échange de 15 minutes la semaine prochaine vous conviendrait-il ?

Si ce n’est pas le bon moment, répondez simplement « stop » : je ne vous écrirai plus.

{Commercial}
Ondée

## M02 · Prospection

Objet : Relance : vos équipes et la pluie

Bonjour {Prénom},

Je me permets de revenir vers vous au sujet de mon message de la semaine dernière. Un client de votre secteur a réduit ses arrêts de tournée les jours de pluie en équipant ses équipes. Puis-je vous en dire plus en 15 minutes ?

Répondez « stop » si vous ne souhaitez plus recevoir mes messages.

{Commercial}
Ondée

## M03 · Rendez-vous

Objet : Confirmation de notre rendez-vous du {Date}

Bonjour {Prénom},

Je vous confirme notre rendez-vous du {Date}. Je vous propose d’aborder vos besoins, le nombre de personnes à équiper et votre calendrier. Vous recevez une invitation dans votre agenda.

À bientôt,
{Commercial}
Ondée

## M04 · Proposition

Objet : {Entreprise} : notre proposition

Bonjour {Prénom},

Merci pour notre échange. Vous trouverez ci-joint notre proposition et notre plaquette. Elle reprend les quantités, la personnalisation et le délai dont nous avons parlé.

Je vous appelle dans quelques jours pour en parler.

{Commercial}
Ondée

## M05 · Proposition

Objet : Votre avis sur notre proposition

Bonjour {Prénom},

Avez-vous pu lire notre proposition ? Je reste disponible pour l’ajuster : quantités, tailles ou calendrier de livraison.

{Commercial}
Ondée

## M06 · Négociation

Objet : {Entreprise} : proposition ajustée

Bonjour {Prénom},

Comme convenu, voici notre proposition ajustée. Elle tient compte de vos remarques sur le délai et le prix. Pour une commande au-delà de 5 000 € HT, la signature revient à votre direction : pouvons-nous prévoir un point avec elle ?

{Commercial}
Ondée

## M07 · Suivi

Objet : Votre livraison Ondée

Bonjour {Prénom},

Votre commande a été livrée. Les tailles conviennent-elles à chacun ? L’échange de taille est gratuit pendant 30 jours.

Une question en deux clics : sur 5, quelle note donnez-vous à cette commande ?

{Commercial}
Ondée

## M08 · Fidélisation

Objet : {Entreprise} : préparer la prochaine saison

Bonjour {Prénom},

Vos équipes portent nos vestes depuis plusieurs mois. Souhaitez-vous équiper les nouveaux arrivants ou compléter avec un pantalon Averse avant l’hiver ? Je peux vous préparer une proposition de réassort.

Et si vous connaissez une entreprise qui pourrait être intéressée, je suis preneur.

{Commercial}
Ondée
