# L’offre professionnelle d’Ondée et ses tarifs

Document fictif, créé pour le cours. Les mêmes chiffres sont dans l’onglet « Catalogue » du fichier data.

## Le catalogue

| Réf. | Produit | Prix HT, de 1 à 49 | Dès 50 | Dès 200 | Fabrication | Minimum |
|---|---|---|---|---|---|---|
| R-01 | Veste Rafale | 139 € | 129 € | 119 € | 21 jours | 20 |
| R-02 | Veste Rafale haute visibilité | 149 € | 139 € | 129 € | 21 jours | 20 |
| R-03 | Pantalon Averse | 82 € | 76 € | 70 € | 21 jours | 20 |
| R-04 | Poncho Grain | 45 € | 41 € | 37 € | 14 jours | 50 |
| R-05 | Casquette Bruine | 20 € | 18 € | 16 € | 14 jours | 50 |
| R-06 | Parka Tempête | 185 € | 172 € | 159 € | 28 jours | 20 |
| S-01 | Broderie du logo | 6 € | 6 € | 5 € | 14 jours | 20 |
| S-02 | Marquage réfléchissant | 4 € | 4 € | 3 € | 7 jours | 20 |
| S-03 | Forfait réparation | 25 € | 25 € | 25 € | 10 jours | 1 |

## Les règles de prix

– Le prix unitaire dépend de la quantité commandée : de 1 à 49 pièces, dès 50, dès 200.
– Broderie du logo : 6 € HT par pièce, plus 90 € HT de mise en route par logo.
– Montant HT d’une commande = (quantité × (prix unitaire + 6 €) + 90 €) × (1 − remise), arrondi à l’euro.
– TVA : 20 %. Livraison offerte dès 1 500 € HT, sinon 25 € HT.
– Devis valable 30 jours ; paiement à 30 jours ; acompte de 30 % au-delà de 10 000 € HT.

## Les règles de négociation

– Remise maximale du commercial : 8 %. Au-delà, la directrice commerciale valide.
– Marge minimale : 30 % du montant HT. En dessous, l’affaire est signalée.
– Chez le client, au-delà de 5 000 € HT, la direction signe : prévoyez un rendez-vous avec le décideur.
– Concessions possibles sans remise : livraison en deux fois, échantillons de tailles, réparation offerte la première année.

## Les engagements

– Échange de taille gratuit pendant 30 jours ;
– garantie de 2 ans sur les coutures et les fermetures ;
– réparation en atelier, retour sous 10 jours.
