# La charte graphique d’Ondée

Document fictif, créé pour le cours. Votre application peut la reprendre ou s’en écarter : c’est votre choix, noté dans CHARTE-GRAPHIQUE.md.

## Les couleurs

– Bleu orage #24476B : titres, en-têtes, logo ;
– jaune ciré #F2C230 : accents, boutons d’action, haute visibilité ;
– gris pluie #E6EAF0 : fonds et cartes ;
– bleu nuit #1B2740 : texte courant ;
– rouge brique #A8425A : alertes et retards.

## La police

Poppins (Google Fonts), en graisse 400 pour le texte et 600 pour les titres.

## Le logo

Une goutte de pluie bleu orage, suivie du mot « Ondée ». Fichiers : logo-ondee.svg et logo-ondee.png. Ne pas le déformer ni le recolorer.

## Le style

Sobre et lumineux : beaucoup de blanc, des coins arrondis, une seule couleur d’accent par écran.
