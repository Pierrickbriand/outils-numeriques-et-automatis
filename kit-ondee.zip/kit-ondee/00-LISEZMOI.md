# Le terrain de jeux : Ondée

Ondée est une entreprise **fictive**, créée pour le cours. Vous y êtes ingénieur d’affaires : vous vendez des vêtements de pluie personnalisés à des entreprises du Grand Ouest. Votre application pilotera vos affaires, de la veille à la fidélisation.

Aucune donnée de ce kit n’est réelle : entreprises, personnes, adresses, téléphones et chiffres sont inventés.

## Ce que contient le kit

| Fichier | Ce qu’il contient | Quand vous en servir |
|---|---|---|
| 01-presentation-ondee.md | L’entreprise, son histoire, son équipe commerciale, ses clients | Séance 1, cadrage |
| 02-offre-et-tarifs.md | Le catalogue professionnel, les prix, les remises, les délais | Proposition, négociation |
| 03-processus-de-vente.md | Les huit étapes, leurs règles et les alertes attendues | Toutes les conversations |
| 04-personas-et-centre-achat.md | Qui achète, qui décide, les objections fréquentes | Qualification, rendez-vous |
| 05-modeles-emails.md | Huit modèles d’e-mails, un par moment du cycle | Prospection, suivi, fidélisation |
| 06-charte-graphique-ondee.md | Couleurs, police et logo d’Ondée | Charte de votre application |
| 07-charte-editoriale-ondee.md | Le ton d’Ondée et ses règles d’écriture | E-mails et textes de l’application |
| 08-modele-devis-ondee.docx | Le modèle de devis, avec ses balises {{…}} | Conversation 08 |
| 09-modele-plaquette-ondee.pptx | Le modèle de plaquette, avec ses balises {{…}} | Conversation 08 |
| 10-revue-de-presse-fictive.md | Huit articles fictifs sur les clients et prospects | Conversation 04, veille |
| 11-ondee-donnees-commerciales.xlsx | Le fichier data : 30 entreprises, 50 contacts, 40 affaires, avec leurs formules | Dès la séance 1 |
| logo-ondee.png et logo-ondee.svg | Le logo d’Ondée | Plaquette, devis, application |

## Ce que vous en faites, dans l’ordre

1. Créez dans Google Drive un dossier au nom de votre application.
2. Déposez-y le fichier data (11), ouvrez-le, puis « Fichier », « Enregistrer au format Google Sheets ». Travaillez désormais sur cette version Google Sheets.
3. Dans l’onglet « Paramètres », case B3 : votre adresse Gmail. Les 50 contacts reçoivent une adresse alias (vous+c01@gmail.com). Chaque e-mail envoyé par votre application arrive donc dans votre propre boîte.
4. En conversation 08 : déposez les modèles de devis (08) et de plaquette (09), puis enregistrez-les au format Google Docs et Google Slides.
5. Ajoutez au projet Claude les documents 01, 02 et 03. Les autres se joignent à la demande, dans la conversation qui en a besoin.

## Découvrir les formules du fichier data

Les cases grises contiennent des formules. Cliquez dessus : vous y lirez INDEX et EQUIV (retrouver une entreprise), SOMME.SI.ENS et NB.SI.ENS (les indicateurs), SI et ET (les alertes), SUBSTITUE (les adresses alias). Les fiches de cours en PDF expliquent chacune d’elles, avec des exercices à refaire chez vous.

## Économiser vos crédits Claude

– Gardez Claude pour le code, les erreurs et les décisions d’architecture.
– Confiez à Gemini, en offre gratuite, ce qui ne demande pas le contexte du projet : idées de noms et de slogans, reformulation d’un e-mail, explication d’une formule, choix de couleurs.
– Une conversation par étape, courte. Quand elle s’allonge, terminez-la avec l’état du projet et ouvrez la suivante.
