# Revue de presse fictive

Huit articles inventés pour le cours, à résumer avec votre application ou avec Claude (conversation 04). Aucune de ces informations n’est réelle.

## 1. Vélo Express ouvre un dépôt à Angers

Le spécialiste nantais de la livraison à vélo ouvre en janvier un dépôt de 15 coursiers à Angers. Son directeur veut « des tournées qui ne s’arrêtent plus à la première averse ».

## 2. Le Val d’Estuaire lance un marché de vêtements de travail

La communauté de communes publie un marché en deux lots, dont un lot « vêtements de pluie » pour 150 agents. Réponses attendues sous un mois.

## 3. Ouest Relais Colis recrute 40 préparateurs

La plateforme de Carquefou renforce ses équipes avant les fêtes. Les quais de chargement sont en partie à l’extérieur.

## 4. Brest Pédale passe l’hiver en équipe complète

La coopérative brestoise recrute six coursiers. Elle cherche des tenues adaptées au vent et à la pluie de la pointe bretonne.

## 5. Taxis vélos de la Côte lève 300 000 euros

La jeune entreprise vendéenne s’installera dans deux nouvelles villes au printemps. Elle prévoit d’équiper ses chauffeurs aux couleurs de la marque.

## 6. Résidences Mer et Pins ouvre un second établissement

Le groupe hôtelier de Saint-Brevin ouvre une seconde résidence. Il veut offrir des ponchos aux couleurs de l’établissement à ses clients.

## 7. Atlantique Propreté Services remporte deux lycées

L’entreprise de propreté de Saint-Herblain assurera l’entretien de deux lycées. Ses agents travaillent tôt le matin, souvent à l’extérieur.

## 8. Les Pédaleurs solidaires obtiennent une subvention

L’association nantaise financera une flotte de vélos cargos pour ses livraisons solidaires et cherche à équiper ses bénévoles.
