# Le processus de vente d’Ondée en huit étapes

Document fictif, créé pour le cours. Chaque affaire du fichier data porte une étape et un statut (En cours, Gagnée, Perdue).

| Étape | Objectif | Critère de passage | Probabilité | Durée cible | Alerte de l’application |
|---|---|---|---|---|---|
| Veille | Repérer un signal d’affaires | Un signal daté et une entreprise identifiée | 5 % | 10 jours | Signal non exploité depuis 7 jours |
| Prospection | Obtenir une réponse | Le contact répond ou accepte un échange | 10 % | 14 jours | Pas de relance à J+7 ; deux relances au plus |
| Qualification | Vérifier besoin, budget, décideur, calendrier | Score de 3 ou 4 sur 4 | 20 % | 10 jours | Décideur inconnu au-delà de 5 000 € HT |
| Rendez-vous | Comprendre le besoin | Rendez-vous tenu, compte rendu envoyé | 40 % | 14 jours | Affaire sans rendez-vous prévu |
| Proposition | Envoyer devis et plaquette | Proposition envoyée et lue | 60 % | 10 jours | Proposition sans réponse depuis 7 jours |
| Négociation | Obtenir l’accord du décideur | Bon de commande signé | 80 % | 14 jours | Remise au-delà de 8 % ; marge sous 30 % |
| Suivi | Livrer et vérifier | Livraison faite, satisfaction notée | 100 % | 30 jours | Retard de livraison ; satisfaction absente |
| Fidélisation | Réassort et recommandation | Nouvelle commande ou recommandation | 100 % | 90 jours | Client sans contact depuis 90 jours |

## Les règles communes

– **Relance** : une affaire en cours sans contact depuis plus de 14 jours passe « À relancer » (Paramètres, B6).
– **Opposition** : un contact qui répond « stop » ne reçoit plus aucun e-mail (Contacts, colonne Opposition).
– **Décideur** : au-delà de 5 000 € HT, le décideur du client signe (Paramètres, B7).
– **Pipeline pondéré** : somme des montants des affaires en cours, multipliés par la probabilité de leur étape.
– **Chaque échange se trace** : une ligne dans l’onglet Interactions, avec la date, le canal et le sens.

## Les indicateurs qualité, coût, délai

– Qualité : satisfaction moyenne des clients livrés, sur 5 ;
– coût : écart entre le coût prévu et le coût réel des commandes ;
– délai : retard moyen de livraison, en jours, et nombre de livraisons en retard.

Ils sont calculés dans l’onglet Indicateurs du fichier data.
