# Le centre d’achat et les personas

Document fictif, créé pour le cours.

## Les quatre rôles du centre d’achat

– **Utilisateur** : porte la veste tous les jours (coursier, agent, jardinier). Il juge le confort et l’étanchéité.
– **Prescripteur** : oriente le choix (responsable sécurité, chef d’exploitation). Il juge la conformité et la sécurité.
– **Acheteur** : compare les offres et négocie (responsable des achats). Il juge le prix, le délai, la fiabilité.
– **Décideur** : signe (direction). Il juge le budget, l’image, le risque.

Un e-mail parle à un rôle à la fois. Le rôle de chaque contact est dans l’onglet Contacts.

## Trois personas

**Lucie Morvan, responsable des achats, Vélo Express (Nantes, 45 coursiers).** Elle compare trois fournisseurs chaque année. Ce qui compte pour elle : un prix stable, une livraison à la date promise, l’échange de taille sans formalité. Son frein : un fournisseur précédent a livré en retard avant l’hiver.

**Karim Benali, directeur, Vélo Express.** Il signe au-delà de 5 000 € HT. Ce qui compte pour lui : moins d’arrêts de tournée les jours de pluie et une image soignée de ses coursiers. Son frein : le budget de l’ouverture du dépôt d’Angers.

**Jade Le Goff, coursière référente, Vélo Express.** Elle teste les échantillons. Ce qui compte pour elle : rester au sec sans avoir trop chaud, des poches étanches pour le téléphone.

## Les objections fréquentes

| Objection | Réponse en quatre temps : écouter, reformuler, prouver, vérifier |
|---|---|
| « C’est plus cher que notre fournisseur. » | Comparer le coût sur la durée : garantie de 2 ans, réparation en atelier, échange de taille. |
| « Vos délais sont trop longs. » | Proposer une livraison en deux fois, les premières tailles sous 3 semaines. |
| « Nous avons déjà un fournisseur. » | Demander ce qui manque ; proposer des échantillons pour une équipe. |
| « Je dois en parler à ma direction. » | Proposer un rendez-vous de 20 minutes avec le décideur. |
| « Le minimum de commande est trop élevé. » | Rappeler le minimum (20 pièces) et proposer un premier lot. |
