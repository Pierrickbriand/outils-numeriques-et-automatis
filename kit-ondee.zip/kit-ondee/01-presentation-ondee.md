# Ondée : présentation de l’entreprise

Document fictif, créé pour le cours.

## L’identité

– Raison sociale : Ondée SAS ;
– siège et atelier : Saint-Nazaire (Loire-Atlantique) ;
– création : 2016, par deux anciens coursiers à vélo ;
– effectif : 38 salariés, dont un atelier de confection et de broderie de 14 personnes ;
– chiffre d’affaires 2025 : 4,2 millions d’euros, dont 30 % auprès des professionnels ;
– promesse : « Rester au sec, en ville comme à vélo » ;
– valeurs : durabilité, réparation, simplicité.

## Ce que fait Ondée

Ondée conçoit et fabrique des vêtements de pluie : vestes, pantalons, ponchos, casquettes et parkas. Les particuliers les achètent en ligne. Les **professionnels** les commandent personnalisées, avec leur logo brodé : entreprises de livraison à vélo, collectivités, entreprises de propreté et d’espaces verts, campings, festivals.

Chaque pièce se répare dans l’atelier de Saint-Nazaire. Les tailles s’échangent gratuitement pendant 30 jours.

## L’équipe commerciale professionnelle

– Maëlle Kervella, directrice commerciale : elle valide les remises au-delà de 8 % et lit les chiffres de chaque lundi ;
– deux ingénieurs d’affaires, dont **vous** : chacun suit une trentaine d’affaires dans le Grand Ouest ;
– Romane Le Dantec, administration des ventes : commandes, factures, livraisons ;
– l’atelier : délai de fabrication de 2 à 4 semaines selon le produit.

Toutes ces personnes sont fictives.

## Les clients professionnels

Le portefeuille compte 30 entreprises clientes ou prospectes (fichier data, onglet Entreprises) :
– livraison et transport à vélo, à Nantes, Angers, Rennes, Brest ;
– collectivités et services techniques ;
– propreté, bâtiment, espaces verts, logistique ;
– tourisme et événementiel.

## Ce qui fait perdre des affaires aujourd’hui

– Les contacts sont dans trois fichiers et deux boîtes e-mail ;
– les relances dépendent de la mémoire de chacun : neuf affaires dorment depuis plus de 14 jours ;
– un devis prend une heure : il faut recopier les prix, calculer la remise, mettre en page ;
– la directrice commerciale reconstruit chaque lundi le point de la semaine à la main.

C’est le problème que votre application doit résoudre.
